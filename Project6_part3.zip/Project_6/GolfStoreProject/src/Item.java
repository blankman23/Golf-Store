/**
 * 
 */

/**
 * @author blank
 *
 */
public class Item{
	
	
private String skueNum,price;
	/**
 * @return the price
 */

public Item(String skueNum, String price){
	
	this.skueNum = skueNum;
	this.price=price;
	
}

public String getPrice() {
	return price;
}

/**
 * @param price the price to set
 */
public void setPrice(String price) {
	this.price = price;
}

public void setSkueNum(String skueNum) {
	
	this.skueNum = skueNum;
}

public String getskueNum() {
	
	return this.skueNum;
}





}
